package org.tiaa.messagegateway.sweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageGatewayApiSwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
